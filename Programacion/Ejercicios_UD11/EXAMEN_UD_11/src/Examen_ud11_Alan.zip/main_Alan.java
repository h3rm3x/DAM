import javax.swing.*;

public class main_Alan {
    public static void main(String[] args) {
        Examen_ud11_Alan programa = new Examen_ud11_Alan();
        programa.panelPrincipal.setVisible(true);
        programa.panelPrincipal.setSize(500, 500);
        programa.panelPrincipal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
