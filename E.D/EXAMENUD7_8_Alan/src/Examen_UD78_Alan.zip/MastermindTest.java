import static org.junit.jupiter.api.Assertions.*;

class MastermindTest {

    @org.junit.jupiter.api.Test
    void jugarMastermind() {
        assertAll(
                assertThrows()
        );
    }
}